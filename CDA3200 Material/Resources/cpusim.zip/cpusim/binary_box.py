from bounding_rectangle import BoundingRectangle
from textbox import Textbox


class BinaryBox:

    def __init__(self, canvas, left, top, value=0, bytes=2, bg='#ffffff', color='#000000', tags=None):
        self.canvas = canvas
        self.value = value
        self.boxes = []
        left += bytes - 1
        for i in range(bytes):
            binstr = format(self.value >> (i * 8) & 255, '08b')
            self.boxes.append(Textbox(canvas, left, top,
                                      value=binstr[0:4] + ' ' + binstr[4:8],
                                      bg=bg, color=color, tags=tags))
            left -= 1

    def set_value(self, value):
        self.value = value
        # update binary values in text boxes
        for i in range(len(self.boxes)):
            binstr = format(self.value >> (i * 8) & 255, '08b')
            self.boxes[i].set_value(binstr[0:4] + ' ' + binstr[4:8])

    def draw(self, x_factor=1, y_factor=1):
        for i in range(len(self.boxes)):
            self.boxes[i].draw(x_factor, y_factor)

    def highlight(self, color='#ffff66', byte=-1):
        for i in range(len(self.boxes)):
            if byte == -1 or byte == i:
                self.boxes[i].highlight(color)

    def un_highlight(self):
        for i in range(len(self.boxes)):
            self.boxes[i].un_highlight()

    def update(self, value):
        self.value = value
        # update binary values in text boxes
        for i in range(len(self.boxes)):
            binstr = format(self.value >> (i * 8) & 255, '08b')
            self.boxes[i].update(binstr[0:4] + ' ' + binstr[4:8])

    def get_box(self, byte=0):
        return self.boxes[byte]
