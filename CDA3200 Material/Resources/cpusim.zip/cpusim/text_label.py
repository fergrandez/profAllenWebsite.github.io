from tkinter import *
from tkinter import font
from bounding_rectangle import BoundingRectangle


class TextLabel(BoundingRectangle):

    def __init__(self, canvas, value, left, top, width=1, height=1, color='#000000', anchor='center', angle=0, tags=None):
        self.canvas = canvas
        super().__init__(left, top, width, height)
        self.value = value
        self.font = font.Font(family="Courier New", size="9", weight="bold")
        self.color = color
        self.anchor = anchor
        self.angle = angle
        self.tags = tags

    def draw(self, x_factor=1, y_factor=1):
        anchor_left, anchor_top = self.get_anchor_point(self.anchor)
        self.canvas.create_text(anchor_left * x_factor,
                                anchor_top * y_factor,
                                text=self.value,
                                font=self.font,
                                fill=self.color,
                                anchor=self.anchor,
                                angle=self.angle,
                                tags=self.tags)
