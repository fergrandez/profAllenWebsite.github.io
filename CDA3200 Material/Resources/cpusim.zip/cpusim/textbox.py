from tkinter import font
from bounding_rectangle import BoundingRectangle


class Textbox(BoundingRectangle):

    def __init__(self, canvas, left, top, width=1, height=1, value=None, bg='#ffffff', color='#000000', anchor='center', tags=None):
        self.canvas = canvas
        super().__init__(left, top, width, height)
        self.value = value
        self.font = font.Font(family="Courier New", size="9", weight="bold")
        self.bg = bg
        self.color = color
        self.anchor = anchor
        self.tags = tags

        self.highlight_color = None

    def draw(self, x_factor=1, y_factor=1):
        # container rectangle
        self.canvas.create_rectangle(self.left * x_factor,
                                     self.top * y_factor,
                                     self.right * x_factor,
                                     self.bottom * y_factor,
                                     fill=self.highlight_color or self.bg,
                                     tags=self.tags)
        # container label
        if self.value:
            anchor_left, anchor_top = self.get_anchor_point(self.anchor)
            self.canvas.create_text(anchor_left * x_factor,
                                    anchor_top * y_factor,
                                    text=self.value,
                                    anchor=self.anchor,
                                    font=self.font,
                                    fill=self.color,
                                    tags=self.tags)

    def highlight(self, color='#ffff66'):
        self.highlight_color = color

    def un_highlight(self):
        self.highlight_color = None

    def set_value(self, value):
        self.value = value

    def update(self, value):
        self.value = value
        self.highlight()
