from component import Component
from register import Register
from text_label import TextLabel

class ArithmeticLogicUnit(Component):

    def __init__(self, canvas, name, left, top, tags=None):
        self.name = name
        super().__init__(canvas, left, top, width=2, height=5, label=self.name, bg='#548235', color='#ffffff', tags=tags)

        self.ir = Register(canvas, 'IR', left, top=top+1, bg='#a9d08e', color='#000000')
        self.acc = Register(canvas, 'ACC', left, top=top+3, width=2, bg='#a9d08e', color='#000000')

        self.sub_components.append(self.ir)
        self.sub_components.append(self.acc)

        self.instruction = TextLabel(canvas, None, self.right, top+2)
        self.zero_flag = TextLabel(canvas, 'Z=0', left, top, width=2, anchor='e')

    def draw(self, x_factor=1, y_factor=1):
        super().draw(x_factor, y_factor)
        if self.instruction:
            self.instruction.draw(x_factor, y_factor)
        self.zero_flag.draw(x_factor, y_factor)

    def highlight(self, register='ir', byte=-1):
        if register == 'ir':
            self.ir.highlight(byte)
        elif register == 'acc':
             self.acc.highlight()

    def un_highlight(self):
        for cnt in self.sub_components:
            cnt.un_highlight()

    def set_instruction(self, instruction=None):
        self.instruction.value = instruction

    def set_zero(self):
        if self.acc.value == 0:
            self.zero_flag.value = 'Z=1'
        else:
            self.zero_flag.value = 'Z=0'

    def do_addition(self, value):
        self.acc.update(self.acc.value + value)
        self.set_zero()
        return self.acc.value

    def do_subtraction(self, value):
        self.acc.update(self.acc.value - value)
        self.set_zero()
        return self.acc.value

    def do_test(self, value):
        self.do_subtraction(value)

    def do_branch_equal(self):
        return self.acc.value == 0

    def do_branch_not_equal(self):
        return self.acc.value != 0
