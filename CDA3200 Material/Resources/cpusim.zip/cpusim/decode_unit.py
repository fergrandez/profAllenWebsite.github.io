from bounding_rectangle import BoundingRectangle
from text_table import TextTable
from component import Component


class DecodeUnit(Component):
    opcodes = [['0000', '0000 0000 0000', ' NOP'],
               ['0001', 'dddd kkkk kkkk', ' LDI Rd,K'],
               ['0010', 'dddd kkkk kkkk', ' LDS Rd,K'],
               ['0011', 'kkkk kkkk rrrr', ' STS K,Rr'],
               ['0100', '0000 dddd rrrr', ' ADD Rd,Rr'],
               ['0101', '0000 dddd rrrr', ' SUB Rd,Rr'],
               ['0110', '0000 dddd rrrr', ' TST Rd,Rr'],
               ['0111', '0000 kkkk kkkk', ' BRE K'],
               ['1000', '0000 kkkk kkkk', ' BRNE K'],
               ['1111', '0000 0000 0000', ' END']]

    def __init__(self, canvas, name, left, top, tags=None):
        self.name = name
        self.value = -1
        super().__init__(canvas, left, top, width=3.35, height=(len(self.opcodes) + 2), label=self.name, bg='#994d00', color='#ffffff', tags=tags)

        self.columns = [['OPCODE', 0.75, 'center'], ['- OPERANDS', 1.5, 'center'], ['   INSTR', 1.1, 'w']]

        self.table = TextTable(canvas, BoundingRectangle(left, top + 1, width=3.35, height=(len(self.opcodes) + 1)),
                               columns=self.columns, values=self.opcodes, tags='DU')

        self.sub_components.append(self.table)

    def draw(self, x_factor=1, y_factor=1):
        self.table.value = format(self.value, '04b')
        super().draw(x_factor, y_factor)

    def highlight(self, opcode):
        self.table.value = format(opcode, '04b')
        self.table.highlight(format(opcode, '04b'), column=-1)

    def un_highlight(self):
        self.table.value = None
        self.table.un_highlight()

    def get_opcode_box(self, opcode):
        return self.table.get_box(format(opcode, '04b'))

    def get_instruction(self, opcode):
        return self.table.get_box(format(opcode, '04b'), column=2).value
