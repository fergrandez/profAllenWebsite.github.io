from text_label import TextLabel
from textbox import Textbox
from component import Component


class ControlUnit(Component):

    def __init__(self, canvas, name, left, top, tags=None):
        self.name = name
        self.value = 0
        super().__init__(canvas, left, top, width=2, height=2, label=self.name, bg='#ff6600', color='#000000', tags=tags)

        self.clock_label = TextLabel(canvas, 'Clock:', left, top + 1, tags=tags)
        self.clock = Textbox(canvas, left + 1, top + 1, tags=tags)

        self.sub_components.append(self.clock_label)
        self.sub_components.append(self.clock)

    def draw(self, x_factor=1, y_factor=1):
        self.clock.value = str(self.value)
        super().draw(x_factor, y_factor)

    def highlight(self):
        self.clock.highlight()

    def un_highlight(self):
        self.clock.un_highlight()

    def update(self, value):
        self.value = value
        self.clock.update(value)
        self.highlight()
