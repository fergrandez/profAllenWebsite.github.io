Open file: cpusim.py
Run