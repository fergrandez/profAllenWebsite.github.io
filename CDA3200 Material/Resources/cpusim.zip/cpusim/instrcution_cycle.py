from enum import Enum
from component import Component
from textbox import Textbox


class Cycle(Enum):
    Terminate = 0
    Fetch = 1
    Decode = 2
    Execute = 3

    def describe(self):
        return self.name


class InstructionCycle(Component):

    def __init__(self, canvas, name, left, top, width=2, height=1, color='#000000', tags=None):
        self.name = name
        self.value = Cycle.Terminate
        super().__init__(canvas, left, top, width=width, height=height, border=False, label=self.name + ':', color=color, anchor='w', tags=tags)
        self.cycle_box = Textbox(canvas, left + 1, top, width=1, value=self.value.describe(), bg='#ffffff', color='#000000', tags=tags)
        self.sub_components.append(self.cycle_box)

    def draw(self, x_factor=1, y_factor=1):
        super().draw(x_factor, y_factor)

    def highlight(self, byte=-1):
        self.cycle_box.highlight(byte)

    def un_highlight(self):
        self.cycle_box.un_highlight()

    def update(self, cycle):
        self.value = cycle
        self.cycle_box.update(self.value.describe())
