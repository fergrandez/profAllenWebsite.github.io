

class BoundingRectangle:

    def __init__(self, left, top, width=1, height=1):
        self.left = left
        self.top = top
        self.width = width
        self.height = height

    def get_right(self):
        return self.left + self.width

    def set_right(self, arg):
        self.width = arg - self.left

    right = property(get_right, set_right)

    def get_bottom(self):
        return self.top + self.height

    def set_bottom(self, arg):
        self.height = arg - self.top

    bottom = property(get_bottom, set_bottom)

    def get_center(self):
        return self.left + self.width / 2

    center = property(fget=get_center)

    def get_middle(self):
        return self.top + self.height / 2

    middle = property(fget=get_middle)

    def get_anchor_point(self, anchor):
        if anchor == 'nw':
            return self.left, self.top
        elif anchor == 'n':
            return self.center, self.top
        elif anchor == 'ne':
            return self.right, self.top
        elif anchor == 'e':
            return self.right, self.middle
        elif anchor == 'se':
            return self.right, self.bottom
        elif anchor == 's':
            return self.center, self.bottom
        elif anchor == 'sw':
            return self.left, self.bottom
        elif anchor == 'w':
            return self.left, self.middle
        elif anchor == 'center':
            return self.center, self.middle

    def is_left(self, other):
        return self.right < other.left

    def is_right(self, other):
        return self.left > other.right

    def is_above(self, other):
        return self.bottom < other.top

    def is_below(self, other):
        return self.top > other.bottom
