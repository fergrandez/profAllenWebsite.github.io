from tkinter import *
import tkinter as tk
from random import randrange

from control_unit import ControlUnit
from register import Register
from decode_unit import DecodeUnit
from arithmetic_logic_unit import ArithmeticLogicUnit
from memory_unit import MemoryUnit
from bus import Bus
from memory_registers import MemoryRegisters
from instrcution_cycle import InstructionCycle
from instrcution_cycle import Cycle

block_width = 72
block_height = 18
highlight_color = '#ffff66'

canvas_width = 12
canvas_height = 39

registers_count = 16
regsiters_start = 0


class CpuSim(Tk):
    cu = None
    pc = None
    mar = None
    mdr = None
    du = None
    alu = None
    code_bus = None
    cab = None
    dab = None
    cdb = None
    ddb = None
    codebus = None
    eprom = None
    databus = None
    sram = None
    registers = None

    programs = [['Demo', [4101, 4392, 16385, 12608, 61440]]]

    fetch_step = -1
    decode_step = -1
    execute_opcode = -1
    execute_new_opcode = -1
    execute_step = -1
    execute_source = -1
    execute_destination = -1

    cycle = None

    animation_steps = 8
    show_animation = True

    def __init__(self):
        super().__init__()
        self.title('CpuSim')

        menubar = Menu(self)
        programsMenu = Menu(menubar, tearoff=0)
        for i in range(len(self.programs)):
            programsMenu.add_command(label='Load: ' + self.programs[i][0], command=lambda: self.load(i))
        menubar.add_cascade(label="Programs", menu=programsMenu)

        self.config(menu=menubar)

        self.canvas = Canvas(self,
                             width=canvas_width * block_width,
                             height=canvas_height * block_height,
                             bg="#99ccff")
        self.canvas.pack(side=BOTTOM)

        self.controls = []
        self.highlights = []
        self.arrows = []
        self.animate = self.animation_steps

        middle = canvas_width / 2 + .25

        self.cycle = InstructionCycle(canvas=self.canvas, name='Cycle', left=middle - 1, top=2, color='#0000ff')
        self.controls.append(self.cycle)
        self.highlights.append(self.cycle)


        self.cu = ControlUnit(canvas=self.canvas, name='CU', left=self.cycle.left, top=self.cycle.bottom + 1, tags='CU')
        self.controls.append(self.cu)
        self.highlights.append(self.cu)
        self.canvas.tag_bind('CU', '<Button-1>', self.clockCycle)
        self.pc = Register(canvas=self.canvas, name='PC', left=self.cu.left, top=self.cu.bottom + 1, width=1)
        self.controls.append(self.pc)
        self.highlights.append(self.pc)
        self.mar = Register(canvas=self.canvas, name='MAR', left=self.cu.left, top=self.pc.bottom + 1, width=1)
        self.controls.append(self.mar)
        self.highlights.append(self.mar)
        self.mdr = Register(canvas=self.canvas, name='MDR', left=self.cu.left, top=self.mar.bottom + 1)
        self.controls.append(self.mdr)
        self.highlights.append(self.mdr)
        self.du = DecodeUnit(canvas=self.canvas, name='DU', left=middle - 1.5, top=self.mdr.bottom + 1)
        self.controls.append(self.du)
        self.highlights.append(self.du)
        self.alu = ArithmeticLogicUnit(canvas=self.canvas, name='ALU', left=self.cu.left, top=self.du.bottom + 1)
        self.controls.append(self.alu)
        self.highlights.append(self.alu)

        self.code_bus = Bus(canvas=self.canvas, name='Memory Bus', left=self.cu.left - 1.5, top=self.cu.top - 1, width=.25, height=34, control_top=self.cu.top+1, address_top=self.mar.top+1, data_top=self.mdr.top+1, direction='r', tags='CODE_BUS')
        self.controls.append(self.code_bus)

        self.eprom = MemoryUnit(canvas=self.canvas, name='EPROM', left=self.code_bus.left - 3.25, top=self.code_bus.top, address_bytes=1, data_bytes=2, labels=['ADDRESS', 'CODE'], tags='EPROM')
        self.controls.append(self.eprom)
        self.highlights.append(self.eprom)

        self.data_bus = Bus(canvas=self.canvas, name='Memory Bus', left=self.cu.right + 1.25, top=self.code_bus.top, width=.25, height=34, control_top=self.cu.top+1, address_top=self.mar.top+1, data_top=self.mdr.top+1, direction='l', tags='DATA_BUS')
        self.controls.append(self.data_bus)

        self.registers = MemoryRegisters(canvas=self.canvas, name='Reg', left=self.data_bus.right + .25, top=self.data_bus.top, number_registers=registers_count, starting_address=regsiters_start, tags='Reg')
        self.controls.append(self.registers)

        self.sram = MemoryUnit(canvas=self.canvas, name='SRAM', left=self.registers.right + .25, top=self.data_bus.top, address_bytes=1, data_bytes=1, labels=['ADDRESS', 'DATA'], tags='SRAM')
        self.controls.append(self.sram)
        self.highlights.append(self.sram)

        self.randomize_memory()

    def randomize_memory(self):
        self.cu.value = randrange(2**8-1)
        self.pc.value = randrange(32)
        self.mar.value = randrange(32)
        self.mdr.value = randrange(2**16-1)
        self.mdr.value = randrange(2**16-1)
        self.alu.ir.value = randrange(2**16-1)
        # self.alu.r1.value = randrange(2**8-1)
        # self.alu.r2.value = randrange(2**8-1)
        for i in range(32):
            self.eprom.set_value(i, randrange(2 ** 16 - 1))
        for i in range(32):
            self.sram.set_value(i, randrange(2**16-1))

    def run(self):
        self.render()
        # if self.animate:
        #     self.animate -= 1
        # else:
        #     self.animate = self.animation_steps
        #     for cnt in self.highlights:
        #         cnt.un_highlight()
        #     self.arrows.clear()
        self.after(500, self.run)

    def render(self):
        self.canvas.delete('all')
        for control in self.controls:
            control.draw(block_width, block_height)
        for arrow in self.arrows:
            self.canvas.create_line(arrow[0][0] * block_width,
                                    arrow[0][1] * block_height,
                                    arrow[1][0] * block_width,
                                    arrow[1][1] * block_height,
                                    arrow=tk.LAST,
                                    fill='#ff0000',
                                    width=2)

    def load(self, programIndex):
        self.cu.value = 0
        self.cu.clock.value = 0
        self.pc.update(0)
        self.mar.value = 0
        self.mar.value = 0
        self.mdr.value = 0
        self.mdr.value = 0
        self.alu.ir.value = 0
        self.alu.acc.value = 0
        for i in range(32):
            if i < len(self.programs[programIndex][1]):
                self.eprom.update(i, self.programs[programIndex][1][i])
            else:
                self.eprom.set_value(i, 0)
            self.sram.set_value(i, 0)

        self.fetch_step = 0
        self.cycle.update(Cycle.Fetch)
        self.decode_step = -1
        self.execute_step = -1

    def clockCycle(self, event):
        # clear previous animations
        for cnt in self.highlights:
            cnt.un_highlight()
        self.arrows.clear()
        # fetch-decode-execute
        self.fetch()
        self.decode()
        self.execute()
        # self.after(1000, lambda: self.clockCycle(None))

    def fetch(self):
        steps = [self.fetch_pc_mar,
                 self.fetch_mar_rom,
                 self.fetch_rom_mdr]

        if self.fetch_step == len(steps):
            self.fetch_step = -1
            self.decode_step = 0
            self.cycle.update(Cycle.Decode)

        elif self.fetch_step > -1:
            steps[self.fetch_step]()
            self.fetch_step += 1

    def decode(self):
        steps = [self.decode_mdr_du,
                 self.decode_du_ir]

        if self.decode_step == len(steps):
            self.fetch_step = -1
            self.decode_step = -1
            self.execute_step = 0
            self.cycle.update(Cycle.Execute)

        elif self.decode_step > -1:
            steps[self.decode_step]()
            self.decode_step += 1

    def execute(self):
        steps = [[self.execute_nop,
                  self.pc_increment],               # 0000 : NOP
                 [self.execute_ir_source_acc,       # 0001 : LDI
                  self.execute_ir_destination_mar,
                  self.execute_acc_mdr,
                  self.execute_mar_sram,
                  self.execute_mdr_sram,
                  self.pc_increment],
                 [self.execute_ir_source_mar,       # 0010 : LDS
                  self.execute_mar_sram,
                  self.execute_sram_mdr],
                 [self.execute_ir_source_mar,       # 0011 : STS
                  self.execute_mar_sram,
                  self.execute_sram_mdr,
                  self.execute_mdr_acc],
                 [self.execute_ir_destination_mar,  # 0100 : ADD
                  self.execute_mar_sram,
                  self.execute_sram_mdr,
                  self.execute_mdr_acc,
                  self.execute_ir_source_mar,
                  self.execute_mar_sram,
                  self.execute_sram_mdr,
                  self.execute_add,
                  self.execute_ir_destination_mar,
                  self.execute_acc_mdr,
                  self.execute_mar_sram,
                  self.execute_mdr_sram,
                  self.pc_increment],
                 [self.execute_ir_destination_mar,  # 0101 : SUB
                  self.execute_mar_sram,
                  self.execute_sram_mdr,
                  self.execute_mdr_acc,
                  self.execute_ir_source_mar,
                  self.execute_mar_sram,
                  self.execute_sub,
                  self.execute_ir_destination_mar,
                  self.execute_acc_mdr,
                  self.execute_mar_sram,
                  self.pc_increment],
                 [self.execute_ir_destination_mar,  # 0110 : test
                  self.execute_mar_sram,
                  self.execute_sram_mdr,
                  self.execute_mdr_acc,
                  self.execute_ir_source_mar,
                  self.execute_mar_sram,
                  self.execute_test,
                  self.pc_increment],
                 [self.execute_bre],                # 0111 : BRE
                 [self.execute_brne],               # 1000 : BRNE
                 [self.execute_ir_pc],              # 1001 : BR-IR-PC
                 [self.execute_mdr_acc,             # 1010 : LDS-Rd
                  self.execute_ir_destination_mar,
                  self.execute_acc_mdr,
                  self.execute_mar_sram,
                  self.execute_mdr_sram,
                  self.pc_increment],
                 [self.execute_ir_destination_mar,  # 1011 : STS-SRAM
                  self.execute_acc_mdr,
                  self.execute_mar_sram,
                  self.execute_mdr_sram,
                  self.pc_increment],
                 [self.execute_nop],                # 1100 : NOP
                 [self.execute_nop],                # 1101 : NOP
                 [self.execute_nop],                # 1110 : NOP
                 [self.execute_end]]                # 1111 : END

        if self.execute_opcode > -1:
            # completed clock cycle
            if self.execute_step == len(steps[self.execute_opcode]):
                self.cu.update(self.cu.value + 1)
                # sub-opcodes
                if self.execute_new_opcode > -1:
                    self.execute_opcode = self.execute_new_opcode
                    self.execute_new_opcode = -1
                    self.execute_step = 0
                else:
                    # if END then terminate fetch
                    if self.execute_opcode == 15:
                        self.fetch_step = -1
                        self.cycle.update(Cycle.Terminate)
                    else:
                        # clear the current instruction
                        self.alu.set_instruction()
                        # start next fetch
                        self.fetch_step = 0
                        self.cycle.update(Cycle.Fetch)
                    self.decode_step = -1
                    self.execute_step = -1
                    self.execute_opcode = -1
            # start executing
            elif self.execute_step > -1:
                # set initial destination/source
                if self.execute_step == 0:
                    if self.execute_opcode in range(1, 3):
                        self.execute_load()
                    elif self.execute_opcode == 3:
                        self.execute_store()
                    elif self.execute_opcode in range(4, 7):
                        self.execute_arithmetic()
                # execute next step
                steps[self.execute_opcode][self.execute_step]()
                self.execute_step += 1

    def fetch_pc_mar(self):
        self.mar.update(self.pc.value)
        self.arrows.append((self.pc.get_anchor_point('s'), self.mar.get_anchor_point('n')))

    def pc_increment(self):
        self.pc.update(self.pc.value + 1)

    def fetch_mar_rom(self):
        self.eprom.set_address(self.mar.value)
        self.eprom.highlight(self.mar.value, 0)
        self.arrows.append((self.mar.get_anchor_point('w'), self.eprom.get_address_box().get_anchor_point('e')))

    def fetch_rom_mdr(self):
        self.mdr.update(self.eprom.get_value(self.mar.value))
        self.arrows.append((self.eprom.get_value_box().get_anchor_point('e'), self.mdr.get_anchor_point('w')))
        self.eprom.set_address(-1)

    def decode_mdr_du(self):
        opcode = self.mdr.value >> 12 & 15
        self.du.highlight(opcode)
        self.arrows.append((self.mdr.get_anchor_point('s'), self.du.get_opcode_box(opcode).get_anchor_point('n')))

    def decode_du_ir(self):
        opcode = self.mdr.value >> 12 & 15
        self.alu.ir.update(self.mdr.value)
        self.alu.set_instruction(self.du.get_instruction(opcode))
        self.arrows.append((self.du.get_opcode_box(opcode).get_anchor_point('s'), self.alu.ir.get_anchor_point('n')))
        self.execute_opcode = opcode

    def get_ir_low_byte(self):
        return self.alu.ir.value & 255

    def get_ir_high_byte(self):
        return self.alu.ir.value >> 8

    def execute_load(self):
        self.execute_source = self.get_ir_low_byte()
        self.execute_destination = self.get_ir_high_byte() & 15

    def execute_store(self):
        self.execute_source = self.get_ir_low_byte() & 15
        self.execute_destination = self.get_ir_high_byte() & 15
        self.execute_destination = self.execute_destination << 4
        self.execute_destination += self.get_ir_low_byte() >> 4

    def execute_arithmetic(self):
        self.execute_source = self.get_ir_low_byte() & 15
        self.execute_destination = self.get_ir_low_byte() >> 4

    def execute_branch(self):
        self.execute_destination = self.get_ir_low_byte()

    def execute_nop(self):
        pass

    def execute_ir_source_acc(self):
        self.alu.acc.update(self.execute_source)
        self.arrows.append((self.alu.ir.get_anchor_point('s'), self.alu.acc.get_box(byte=0).get_anchor_point('center')))

    def execute_ir_destination_mar(self):
        self.mar.update(self.execute_destination)
        self.arrows.append((self.alu.ir.get_anchor_point('n'), self.mar.get_anchor_point('s')))

    def execute_ir_source_mar(self):
        self.mar.update(self.execute_source)
        self.arrows.append((self.alu.ir.get_anchor_point('n'), self.mar.get_anchor_point('s')))

    def execute_lds_destination_mar(self):
        self.mar.update(self.get_ir_high_byte() & 15)
        self.arrows.append((self.alu.ir.get_box(byte=1).get_anchor_point('n'), self.mar.get_anchor_point('s')))

    def execute_sts_source_mar(self):
        self.mar.update(self.get_ir_low_byte() & 15)
        self.arrows.append((self.alu.ir.get_box(byte=1).get_anchor_point('n'), self.mar.get_anchor_point('s')))

    def execute_ir_car(self):
        self.mar.update(self.alu.ir.value & 255)
        self.arrows.append((self.alu.ir.get_box(byte=0).get_anchor_point('n'), self.mar.get_anchor_point('s')))

    def execute_acc_mdr(self):
        value = self.alu.acc.value & 255
        self.mdr.update(value)
        self.arrows.append((self.alu.acc.get_box(byte=0).get_anchor_point('n'), self.mdr.get_anchor_point('s')))

    def execute_mar_sram(self):
        self.sram.set_address(self.mar.value)
        self.sram.highlight(self.mar.value, 0)
        self.arrows.append((self.mar.get_anchor_point('e'), self.sram.get_address_box().get_anchor_point('w')))

    def execute_sram_mdr(self):
        self.mdr.update(self.sram.get_value(self.mar.value))
        self.arrows.append((self.sram.get_value_box().get_anchor_point('w'), self.mdr.get_anchor_point('e')))
        if self.execute_opcode == 2:
            self.execute_new_opcode = 10

    def execute_mdr_acc(self):
        self.alu.acc.update(self.mdr.value)
        self.arrows.append((self.mdr.get_anchor_point('s'), self.alu.acc.get_box(byte=0).get_anchor_point('n')))
        if self.execute_opcode == 3:
            self.execute_new_opcode = 11

    def execute_mdr_sram(self):
        self.sram.update(self.mar.value, self.mdr.value)
        self.arrows.append((self.mdr.get_anchor_point('e'), self.sram.get_value_box().get_anchor_point('w')))

    def execute_add(self):
        self.alu.do_addition(self.mdr.value)
        self.arrows.append((self.mdr.get_anchor_point('s'), self.alu.acc.get_anchor_point('n')))

    def execute_sub(self):
        self.alu.do_subtraction(self.mdr.value)
        self.arrows.append((self.mdr.get_anchor_point('s'), self.alu.acc.get_anchor_point('n')))

    def execute_test(self):
        self.alu.do_test(self.mdr.value)
        self.arrows.append((self.mdr.get_anchor_point('s'), self.alu.acc.get_anchor_point('n')))

    def execute_bre(self):
        if self.alu.do_branch_equal():
            self.execute_new_opcode = 9

    def execute_brne(self):
        if self.alu.do_branch_not_equal():
            self.execute_new_opcode = 9

    def execute_ir_pc(self):
        self.pc.update(self.alu.ir.value & 255)
        self.arrows.append((self.alu.ir.get_box(byte=0).get_anchor_point('n'), self.pc.get_anchor_point('s')))

    def execute_end(self):
        pass

# ---------------------------------------------------------
# main program


def main():

    cpu = CpuSim()

    cpu.run()
    cpu.mainloop()

if __name__ == '__main__':
    main()
