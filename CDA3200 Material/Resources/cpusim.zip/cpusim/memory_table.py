from bounding_rectangle import BoundingRectangle
from text_label import TextLabel
from binary_box import BinaryBox


class MemoryTable:

    def __init__(self, canvas, bbox, rows, values=None, labels=None, address_bytes=1, data_bytes=1,
                 address_bg='#ffffff', address_color='#000000', data_bg='#ffffff', data_color='#000000', tags=None):
        self.canvas = canvas
        self.bbox = bbox
        self.rows = rows
        self.address_bytes = address_bytes
        self.data_bytes = data_bytes

        self.labels = []
        left = self.bbox.left
        top = self.bbox.top
        if labels:
            self.labels.append(TextLabel(canvas, labels[0], left, top, width=address_bytes, tags=tags))
            self.labels.append(TextLabel(canvas, labels[1], left+address_bytes, top, width=data_bytes, tags=tags))
            top += 1

        self.values = []
        for i in range(rows):
            value = 0
            if values:
                if i <= len(values):
                    value = values[i]
            row = [BinaryBox(canvas, left, top, value=i, bytes=address_bytes, bg=address_bg, color=address_color, tags=tags),
                   BinaryBox(canvas, left+address_bytes, top, value=value, bytes=data_bytes, bg=data_bg, color=data_color, tags=tags)]
            self.values.append(row)
            top += 1

        self.value = None
        self.highlights = []

    def set_value(self, address, value):
        self.values[address][1].set_value(value)

    def get_value(self, address):
        return self.values[address][1].value

    def draw(self, x_factor=1, y_factor=1):

        if self.labels:
            for i in range(len(self.labels)):
                self.labels[i].draw(x_factor, y_factor)

        for i in range(self.rows):
            highlight_color = None
            highlight_column = -1
            for h in range(len(self.highlights)):
                if self.highlights[h][0] == i:
                    highlight_color = self.highlights[h][1]
                    highlight_column = self.highlights[h][2]
            for j in range(2):
                self.values[i][j].draw(x_factor, y_factor)
                if highlight_color and highlight_column == -1 or highlight_column == j:
                    self.values[i][j].highlight(color=highlight_color)

    def highlight(self, address, highlight='#ffff66', column=-1):
        self.highlights.append((address, highlight, column))

    def un_highlight(self):
        self.highlights.clear()
        for i in range(self.rows):
            for j in range(2):
                self.values[i][j].un_highlight()

    def get_address_box(self, byte=0):
        return self.values[self.value][0].boxes[byte]

    def get_value_box(self, byte=0):
        return self.values[self.value][1].boxes[byte]

    def update(self, address, value):
        self.set_value(address, value)
        self.highlight(address, column=1)
