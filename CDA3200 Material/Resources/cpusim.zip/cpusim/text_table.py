from tkinter import font
from text_label import TextLabel
from textbox import Textbox


class TextTable:

    def __init__(self, canvas, bbox, columns, values, bg='#ffffff', color='#000000', anchor='center', tags=None):
        self.canvas = canvas
        self.bbox = bbox

        self.columns = []
        left = self.bbox.left
        top = self.bbox.top
        for i in range(len(columns)):
            self.columns.append(TextLabel(canvas, columns[i][0], left, top, width=columns[i][1], anchor=columns[i][2], tags=tags))
            self.columns[i].font = font.Font(family="Courier New", size="8", weight="bold")
            left += columns[i][1]

        top += 1
        self.values = []
        for i in range(len(values)):
            left = self.bbox.left
            row_values = []
            for j in range(len(columns)):
                row_values.append(Textbox(canvas, left, top + i, width=columns[j][1], value=values[i][j], bg=bg, color=color, anchor=columns[j][2], tags=tags))
                left += columns[j][1]
            self.values.append(row_values)

        self.value = None
        self.highlights = []

    def draw(self, x_factor=1, y_factor=1):

        if self.columns:
            for i in range(len(self.columns)):
                self.columns[i].draw(x_factor, y_factor)

        for i in range(len(self.values)):
            highlight_color = None
            highlight_column = -1
            for h in range(len(self.highlights)):
                if self.highlights[h][0] == self.values[i][0].value:
                    highlight_color = self.highlights[h][1]
                    highlight_column = self.highlights[h][2]
            for j in range(len(self.columns)):
                self.values[i][j].draw(x_factor, y_factor)
                if highlight_color and highlight_column == -1 or highlight_column == j:
                    self.values[i][j].highlight(color=highlight_color)

    def highlight(self, key, column=-1, color='#ffff66'):
        self.highlights.append((key, color, column))

    def un_highlight(self):
        for i in range(len(self.values)):
            for j in range(len(self.columns)):
                self.values[i][j].un_highlight()
        self.highlights.clear()

    def get_box(self, key, column=0):
        for h in range(len(self.values)):
            if self.values[h][0].value == key:
                return self.values[h][column]

