from bounding_rectangle import BoundingRectangle
from component import Component
from memory_table import MemoryTable


class MemoryUnit(Component):

    def __init__(self, canvas, name, left, top, rows=32, labels=None, address_bytes=1, data_bytes=1, tags=None):
        self.name = name
        self.value = -1
        height = rows + 1
        if labels:
            height += 1
        super().__init__(canvas, left, top, width=address_bytes+data_bytes, height=height, label=self.name, bg='#646468', color='#ffffff', tags=self.name)

        height -= 1
        self.table = MemoryTable(canvas, BoundingRectangle(left, top+1, width=address_bytes+data_bytes, height=height),
                                 rows=rows, values=None, labels=labels, address_bytes=address_bytes, data_bytes=data_bytes,
                                 address_bg='#d8d8da', tags=tags)
        self.sub_components.append(self.table)

    def set_address(self, address):
        self.value = address
        self.table.value = self.value

    def get_value(self, address):
        return self.table.get_value(address)

    def set_value(self, address, value):
        self.table.set_value(address, value)

    def draw(self, x_factor=1, y_factor=1):
        super().draw(x_factor, y_factor)

    def highlight(self, address, column=-1):
        self.table.highlight(address, column=column)

    def un_highlight(self):
        self.table.un_highlight()

    def get_address_box(self, byte=0):
        return self.table.get_address_box(byte)

    def get_value_box(self, byte=0):
        return self.table.get_value_box(byte)

    def update(self, address, value):
        self.table.update(address, value)
