from component import Component
from binary_box import BinaryBox


class Register(Component):

    def __init__(self, canvas, name, left, top, width=2, height=2, bg='#0066ff', color='#ffffff', tags=None):
        self.name = name
        self.value = 0
        super().__init__(canvas, left, top, width=width, height=height, label=self.name, bg=bg, color=color, tags=tags)
        self.binval = BinaryBox(canvas, left, top+1, bytes=width, tags=tags)
        self.sub_components.append(self.binval)

    def draw(self, x_factor=1, y_factor=1):
        super().draw(x_factor, y_factor)

    def highlight(self, byte=-1):
        self.binval.highlight(byte)

    def un_highlight(self):
        self.binval.un_highlight()

    def update(self, value):
        self.value = value
        self.binval.update(value)

    def get_box(self, byte=0):
        return self.binval.get_box(byte)
