from component import Component
from text_label import TextLabel


class MemoryRegisters(Component):

    def __init__(self, canvas, name, left, top, number_registers=0, starting_address=0, tags=None):
        self.name = name
        super().__init__(canvas, left, top, width=.25, height=number_registers, border=False, label=None, bg=None, color=None, tags=tags)
        top += 2    # for labels

        self.number_registers = number_registers
        self.starting_index = starting_address

        top += starting_address

        self.registers = []
        for i in range(number_registers):
            self.registers.append(TextLabel(canvas, 'R'+str(i), left, top, width=0.25, color='#0000ff', anchor='w', tags='R'+str(i)))
            top += 1

    def draw(self, x_factor=1, y_factor=1):
        super().draw(x_factor, y_factor)
        for register in self.registers:
            register.draw(x_factor, y_factor)
