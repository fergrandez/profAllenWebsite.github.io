from component import Component


class Bus(Component):

    def __init__(self, canvas, name, left, top, width, height, control_top, address_top, data_top, direction='r', tags=None):
        self.name = name
        super().__init__(canvas, left, top, width=width, height=height, label=self.name, bg='#0000ff', color='#ffffff', anchor='center', angle=90, tags=tags)

        if direction == 'r':
            left += width
        else:
            left -= 1
        self.control_bus = Component(canvas, left, control_top, width=1, height=1, label='Ctrl Bus', bg='#0000ff', color='#ffffff', anchor='center', tags=tags)
        self.address_bus = Component(canvas, left, address_top, width=1, height=1, label='Addr Bus', bg='#0000ff', color='#ffffff', anchor='center', tags=tags)
        self.data_bus = Component(canvas, left, data_top, width=1, height=1, label='Data Bus', bg='#0000ff', color='#ffffff', anchor='center', tags=tags)

        self.sub_components.append(self.control_bus)
        self.sub_components.append(self.address_bus)
        self.sub_components.append(self.data_bus)

    def draw(self, x_factor=1, y_factor=1):
        super().draw(x_factor, y_factor)

