from tkinter import font
from bounding_rectangle import BoundingRectangle


class Component(BoundingRectangle):

    def __init__(self, canvas, left, top, width=2, height=2, border=True, label=None, bg='#ffffff', color='#000000', anchor='n', angle=0, tags=None):
        self.canvas = canvas
        super().__init__(left, top, width, height)
        self.border = border
        self.label = label
        self.font = font.Font(family="Courier New", size="8", weight="bold")
        self.bg = bg
        self.color = color
        self.anchor = anchor
        self.angle = angle
        self.tags = tags
        self.sub_components = []
        self.higlight_color = None

    def draw(self, x_factor=1, y_factor=1):
        # component rectangle
        if self.border:
            self.canvas.create_rectangle(self.left * x_factor,
                                         self.top * y_factor,
                                         self.right * x_factor,
                                         self.bottom * y_factor,
                                         fill=self.bg,
                                         tags=self.tags)
        # component label
        if self.label:
            anchor_left, anchor_top = self.get_anchor_point(self.anchor)
            self.canvas.create_text(anchor_left * x_factor,
                                    anchor_top * y_factor,
                                    text=self.label,
                                    anchor=self.anchor,
                                    font=self.font,
                                    fill=self.color,
                                    angle=self.angle,
                                    tags=self.tags)

        for cnt in self.sub_components:
            cnt.draw(x_factor, y_factor)
